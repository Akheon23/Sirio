#include "featuretracker.h"

/*FeatureTracker::FeatureTracker()
{
}*/

FeatureTracker::~FeatureTracker()
{
}
