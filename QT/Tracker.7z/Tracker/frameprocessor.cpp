#include "frameprocessor.h"

FrameProcessor::FrameProcessor()
{
}

FrameProcessor::~FrameProcessor()
{
}
