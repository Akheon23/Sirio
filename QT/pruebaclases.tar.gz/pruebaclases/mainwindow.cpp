#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    int num=0;
    cv::Mat Patch;//crea una imagen de dimensiones 0
    cv::Mat resul;
    cv::Mat frame2;
    cv::BackgroundSubtractorMOG mog;
    Patch = cv::imread("/home/lex/Cv/Images/placath1.png");//carga una imagen de una ruta
    cv::VideoCapture frame;
    frame.open("/home/lex/Cv/Videos/pool_flicker_left.wmv");

        int key = 0;
              while (key != 27)
              {
                  cv::Mat_<cv::Vec3b> image;
                  frame.grab();
                  frame.retrieve(frame2);
                   cv::cvtColor(frame2,frame2,CV_BGR2RGB);//obtiene frame en escala de grises
                  QImage img= QImage((const unsigned char*)(frame2.data),frame2.cols,frame2.rows,QImage::Format_RGB888);//extrae imagen
                  ui->label->setPixmap(QPixmap::fromImage(img));//muestra en label el video
                   cv::namedWindow("original image");//crea ventana para mostrar la imagen
                  //hand2.MatchT(frame2,Patch, resul);
                  //cv::threshold(resul,resul,200,255,cv::THRESH_BINARY);

                 // qDebug()<<num;
                 // num=0;
                 // cv::imshow("camera",resul);
                  key = cv::waitKey(10);

              }

}
